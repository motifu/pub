from django.apps import AppConfig


class TenancyConfig(AppConfig):
    name = 'tenancy'
